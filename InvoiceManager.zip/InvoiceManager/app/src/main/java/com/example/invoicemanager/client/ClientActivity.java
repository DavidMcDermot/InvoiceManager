package com.example.invoicemanager.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Toast;

import com.example.invoicemanager.R;
import com.example.invoicemanager.pdfs.MainAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ClientActivity extends AppCompatActivity {

    private RecyclerView clientsRV;
    private static final int ADD_CLIENT_REQUEST = 1;
    private static final int EDIT_COURSE_REQUEST = 2;
    private ClientViewModel viewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);

        clientsRV = findViewById(R.id.idRVClients);
        FloatingActionButton fab = findViewById(R.id.idFABAdd);

        // adding on click listener for floating action button.
        fab.setOnClickListener(v -> {
            // starting new activity for adding clients
            Intent intent = new Intent(ClientActivity.this, ClientCreation.class);
            startActivityForResult(intent, ADD_CLIENT_REQUEST);
        });

        // setting layout manager to our adapter class.
        clientsRV.setLayoutManager(new LinearLayoutManager(this));
        clientsRV.setHasFixedSize(true);

        // initializing adapter for recycler view.
        final ClientRVAdapter adapter = new ClientRVAdapter();

        clientsRV.setAdapter(adapter);


        viewModel = new ViewModelProvider(this).get(ClientViewModel.class);

        // get all clients from view model
        viewModel.getAllClients().observe(this, new Observer<List<Client>>() {
            @Override
            public void onChanged(List<Client> models) {
                // when the data is changed in model list is added to adapter
                adapter.submitList(models);
            }
        });

        // adds swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // when item swiped the client is deleted from database
                //dialog box to make sure user wants to delete
                AlertDialog.Builder builder = new AlertDialog.Builder(viewHolder.itemView.getContext());
                builder.setMessage("Are you sure you want to delete this client?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                viewModel.deleteClient(adapter.getClientAt(viewHolder.getAdapterPosition()));
                                Toast.makeText(viewHolder.itemView.getContext(), "Client deleted successfully", Toast.LENGTH_SHORT).show();
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                adapter.notifyDataSetChanged();
                            }
                        });
                builder.show();
            }
        }).attachToRecyclerView(clientsRV);

        adapter.setOnItemClickListener(new ClientRVAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Client model) {
                //when clicked new activity is started to display information
                Intent intent = new Intent(ClientActivity.this, ClientCreation.class);
                intent.putExtra(ClientCreation.EXTRA_ID, model.getId());
                intent.putExtra(ClientCreation.EXTRA_CLIENT_NAME, model.getName());
                intent.putExtra(ClientCreation.EXTRA_CLIENT_EMAIL, model.getEmail());
                intent.putExtra(ClientCreation.EXTRA_CLIENT_ADD, model.getAddress());

                startActivityForResult(intent, EDIT_COURSE_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_CLIENT_REQUEST && resultCode == RESULT_OK) {
            String clientName = data.getStringExtra(ClientCreation.EXTRA_CLIENT_NAME);
            String clientEmail = data.getStringExtra(ClientCreation.EXTRA_CLIENT_EMAIL);
            String  clientAdd = data.getStringExtra(ClientCreation.EXTRA_CLIENT_ADD);
            Client client = new Client(clientName, clientEmail, clientAdd);
            viewModel.insertClient(client);
            Toast.makeText(this, "Client updated", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_COURSE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(ClientCreation.EXTRA_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Client can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String clientName = data.getStringExtra(ClientCreation.EXTRA_CLIENT_NAME);
            String clientEmail = data.getStringExtra(ClientCreation.EXTRA_CLIENT_EMAIL);
            String clientAdd = data.getStringExtra(ClientCreation.EXTRA_CLIENT_ADD);
            Client client = new Client(clientName, clientEmail, clientAdd);
            client.setId(id);
            viewModel.updateClient(client);
            Toast.makeText(this, "Client updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Client not saved", Toast.LENGTH_SHORT).show();
        }
    }
}