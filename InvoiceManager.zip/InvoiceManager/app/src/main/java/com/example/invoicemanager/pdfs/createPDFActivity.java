package com.example.invoicemanager.pdfs;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.example.invoicemanager.R;
import com.example.invoicemanager.client.AppDatabase;
import com.example.invoicemanager.client.Client;
import com.example.invoicemanager.client.ClientDao;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hendrix.pdfmyxml.viewRenderer.AbstractViewRenderer;
import com.hendrix.pdfmyxml.PdfDocument;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class createPDFActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText date, clientName, clientAdd1,clientAdd2,clientAdd3,fileName, workDone, workDoneCost, materials, materialsCost,
            totalCost, vatCost, busName,busAdd1,busAdd2,busAdd3,busVatNum;
    FloatingActionButton sharePdf, savePdf;

    public ClientDao clientDao;

    String clientEmail;
    String title;
    Double vatP;

    SharedPreferences businessPreferences;

    private static final int PERMISSION_REQUEST_CODE = 200;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_pdfactivity);
        //get saved business preferences
        businessPreferences = getSharedPreferences("bus_preferences", Context.MODE_PRIVATE);

            date = findViewById(R.id.pdf_dateEt);

            busName = findViewById(R.id.busNameEt);
            busAdd1 = findViewById(R.id.busAddressL1Et);
            busAdd2 = findViewById(R.id.busAddressL2Et);
            busAdd3 = findViewById(R.id.busAddressL3Et);
            busVatNum = findViewById(R.id.busVatNumEt);


            clientName = findViewById(R.id.clientNameEt);
            clientAdd1 = findViewById(R.id.clientAdd1Et);
            clientAdd2 = findViewById(R.id.clientAdd2Et);
            clientAdd3 = findViewById(R.id.clientAdd3Et);

            workDone = findViewById(R.id.workDoneEt);
            workDoneCost = findViewById(R.id.workDoneCostEt);
            totalCost = findViewById(R.id.totalCostEt);

            materials = findViewById(R.id.materialsEt);
            materialsCost = findViewById(R.id.materialsCostEt);

            vatCost = findViewById((R.id.vatCostEt));

            fileName = findViewById(R.id.pdfNameEt);
            savePdf = findViewById(R.id.pdfCreate);
            sharePdf = findViewById(R.id.pdfShare);




            //spinner for title
            Spinner titleSpinner = (Spinner) findViewById(R.id.pdf_title);
            // Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.title_array, android.R.layout.simple_spinner_item);
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // Apply the adapter to the spinner
            titleSpinner.setAdapter(adapter);
            titleSpinner.setPrompt("Select Title");
            titleSpinner.setOnItemSelectedListener(this);

            //spinner for VAT rate
             Spinner VATSpinner = (Spinner) findViewById(R.id.vat_spinner);
             // Create an ArrayAdapter using the string array and a default spinner layout
             ArrayAdapter<CharSequence> Vatadapter = ArrayAdapter.createFromResource(this,
                  R.array.VAT_array, android.R.layout.simple_spinner_item);
                // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // Apply the adapter to the spinner
            VATSpinner.setAdapter(Vatadapter);
            VATSpinner.setSelection(0,false);
            VATSpinner.setOnItemSelectedListener(this);

        // checking permissions
        if (checkPermission()) {

        } else {
            requestPermission();
        }

        //creates then shares pdf through email
        sharePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    sharePDF();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


        // creates pdf file
        savePdf.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                try {
                    generatePDF();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        //automatically fill out client info when client name is input bu querying database
        clientName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                retrieveClient();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }

    public void onItemSelected(AdapterView<?> parent, View v, int position, long id ){
        Spinner spin = (Spinner)parent;
        Spinner spin2 = (Spinner)parent;
        if(spin.getId() == R.id.pdf_title)
        {
            title = spin.getItemAtPosition(position).toString();
        }
        if (spin2.getId() == R.id.vat_spinner) {
            double workC = 0.0;
            double matC = 0.0;
            double vatR;

            String workCStr = workDoneCost.getText().toString();
            String matCStr = materialsCost.getText().toString();

            if (!workCStr.isEmpty() && !workCStr.contains("Work Cost")) {
                workC = Double.parseDouble(workCStr);
            }

            if (!matCStr.isEmpty() && !matCStr.contains("Mat Cost")) {
                matC = Double.parseDouble(matCStr);
            }

            vatR = Double.parseDouble(parent.getSelectedItem().toString());
            vatP = vatR;

            calcVat(workC, matC, vatR);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast.makeText(this, "Please select title and VAT %", Toast.LENGTH_SHORT).show();
    }

    // create the pdf file based off of user input
    private void generatePDF() throws IOException {
        AbstractViewRenderer page = new AbstractViewRenderer(this, R.layout.pdf_layout) {

            String pdfDate = date.getText().toString();

            String clName = clientName.getText().toString();
            String clAdd1 = clientAdd1.getText().toString();
            String clAdd2 = clientAdd2.getText().toString();
            String clAdd3 = clientAdd3.getText().toString();

            String bus_name = busName.getText().toString();
            String bus_add1 = busAdd1.getText().toString();
            String bus_add2 = busAdd2.getText().toString();
            String bus_add3 = busAdd3.getText().toString();
            String bus_vat_num = busVatNum.getText().toString();

            String workDun = workDone.getText().toString();
            String workDunCost = workDoneCost.getText().toString();
            String mats = materials.getText().toString();
            String matsCost = materialsCost.getText().toString();

            String vatC = vatCost.getText().toString();
            String total = totalCost.getText().toString();


            @Override
            protected void initView(View view) {

                String curr = "\u20AC";
                String per = "\u0025";
                if(pdfDate.isEmpty()){
                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    pdfDate = dateFormat.format(calendar.getTime());
                }

                if(bus_name.isEmpty()){
                    bus_name = businessPreferences.getString("business_name", null);
                    bus_add1 = businessPreferences.getString("business_add1", null);
                    bus_add2 = businessPreferences.getString("business_add2", null);
                    bus_add3 = businessPreferences.getString("business_add3", null);
                    bus_vat_num = businessPreferences.getString("business_vat_number", null);
                }


                //set text of pdf being created
                TextView titleEt = view.findViewById(R.id.pdf_titleTv);
                titleEt.setText(title);

                TextView dateEt = view.findViewById(R.id.pdf_dateTv);
                dateEt.setText(pdfDate);

                TextView busNameTv = view.findViewById(R.id.busNameTv);
                busNameTv.setText(bus_name);

                TextView busAdd1Tv = view.findViewById(R.id.BusAddressL1Tv);
                busAdd1Tv.setText(bus_add1);

                TextView busAdd2Tv = view.findViewById(R.id.BusAddressL2Tv);
                busAdd2Tv.setText(bus_add2);

                TextView busAdd3Tv = view.findViewById(R.id.BusAddressL3Tv);
                busAdd3Tv.setText(bus_add3);

                TextView busVatNumTv = view.findViewById(R.id.BusVatNumTv);
                busVatNumTv.setText(bus_vat_num);

                TextView client_name = view.findViewById(R.id.clientNameTv);
                client_name.setText(clName);

                TextView client_add1 = view.findViewById(R.id.clientAdd1Tv);
                client_add1.setText(clAdd1);

                TextView client_add2 = view.findViewById(R.id.clientAdd2Tv);
                client_add2.setText(clAdd2);

                TextView client_add3 = view.findViewById(R.id.clientAdd3Tv);
                client_add3.setText(clAdd3);

                TextView work_done = view.findViewById(R.id.workDoneTv);
                work_done.setText(workDun);

                TextView work_cost = view.findViewById(R.id.workDoneCostTv);
                work_cost.setText(curr + workDunCost);

                TextView material_used = view.findViewById(R.id.materialsTv);
                material_used.setText(mats);

                TextView mats_cost = view.findViewById(R.id.materialsCostTv);
                mats_cost.setText(curr + matsCost);

                TextView vat_rate = view.findViewById(R.id.vatTv);
                vat_rate.setText(vatP + per);

                TextView vat_cost = view.findViewById(R.id.vatCostTv);
                vat_cost.setText(vatC);

                TextView total_cost = view.findViewById(R.id.totalCostTv);
                total_cost.setText(total);

            }
        };


        page.setReuseBitmap(true);


        String fileN = fileName.getText().toString();

        if(title.contains("Select Title")){
            Toast.makeText(this, "Please Choose a Title", Toast.LENGTH_SHORT).show();
        }else if(title.contains("Invoice")) {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Invoices");
            if (!dir.exists()) {
                dir.mkdir();
            }

            new PdfDocument.Builder(this).addPage(page).orientation(PdfDocument.A4_MODE.PORTRAIT)
                    .renderWidth(2115).renderHeight(2300)
                    .saveDirectory(dir)
                    .filename(fileN)
                    .listener(new PdfDocument.Callback() {
                        @Override
                        public void onComplete(File file) {
                            Log.i(PdfDocument.TAG_PDF_MY_XML, "Complete");
                            Toast.makeText(createPDFActivity.this, "PDF created", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onError(Exception e) {
                            Log.i(PdfDocument.TAG_PDF_MY_XML, "Error");
                            Toast.makeText(createPDFActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    }).create().createPdf(this);
        }else if(title.contains("Estimate")) {

            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Estimates");

            if (!dir.exists()) {
                dir.mkdirs();
            }

            new PdfDocument.Builder(this).addPage(page).orientation(PdfDocument.A4_MODE.PORTRAIT)
                    .renderWidth(2115).renderHeight(2300)
                    .saveDirectory(dir)
                    .filename(fileN)
                    .listener(new PdfDocument.Callback() {
                        @Override
                        public void onComplete(File file) {
                            Log.i(PdfDocument.TAG_PDF_MY_XML, "Complete");
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.i(PdfDocument.TAG_PDF_MY_XML, "Error");
                        }
                    }).create().createPdf(this);
        }
    }

    //creates and shares pdf through email
    private void sharePDF() throws IOException {

        generatePDF();


        String fileN = fileName.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/pdf");

        File file = new File(String.valueOf(getExternalFilesDir(fileN + ".pdf")));
        Uri uri = FileProvider.getUriForFile(this, "com.example.invoicemanager.fileprovider", file);

        if (title.contains("Estimate")) {
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{clientEmail});  // recipients email address
            intent.putExtra(Intent.EXTRA_SUBJECT, "Estimate");  // email subject
        } else {
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{clientEmail});  // recipients email address
            intent.putExtra(Intent.EXTRA_SUBJECT, "Invoice");  // email subject
        }

        intent.putExtra(Intent.EXTRA_STREAM, uri);

        Intent chooser = Intent.createChooser(intent, "Share File");

        // Grant temporary read permission to the content URI
        List<ResolveInfo> resInfoList = this.getPackageManager().queryIntentActivities(chooser, PackageManager.MATCH_DEFAULT_ONLY);

        for (ResolveInfo resolveInfo : resInfoList) {
            String packageName = resolveInfo.activityInfo.packageName;
            this.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        startActivity(chooser);
    }

    private void retrieveClient() {
        String name = clientName.getText().toString();
        new RetrieveClientTask().execute(name);
    }

    private class RetrieveClientTask extends AsyncTask<String, Void, Client> {

        @Override
        protected Client doInBackground(String... clientN) {
            String name = clientN[0];
            AppDatabase appDatabase = AppDatabase.getInstance(createPDFActivity.this);
            clientDao = appDatabase.clientDao();
            return clientDao.findByName(name);
        }

        @Override
        protected void onPostExecute(Client client) {
            if (client != null) {
                String str = client.getAddress();
                String[] add = str.split(",");
                String line1 = add[0]; // address line 1
                String line2 = add[1]; // address line 2
                String line3 = ""; // initialize line3 to an empty string

                try {
                    line3 = add[2]; // try to access the 3rd element of the array
                } catch (ArrayIndexOutOfBoundsException e) {
                    // set line3 to an empty string if there is no 3rd element in the array
                    line3 = "";
                }

                // Update UI here with the retrieved data
                clientAdd1.setText(line1);
                clientAdd2.setText(line2);
                clientAdd3.setText(line3);

                clientEmail = client.getEmail();

            }

        }
    }

    private void calcVat(double workC, double matC, double vat){
        String euro = "\u20AC";

        // Input validation to ensure workC and matC are not null
        if (Double.isNaN(workC)) {
            workC = 0.0; // set workC to 0 if it is null
        }

        if (Double.isNaN(matC)) {
            matC = 0.0; // set matC to 0 if it is null
        }

        double t = workC + matC;

        double vatC = t * (vat/100.0);

        double total = t + vatC;

        vatCost.setText(euro + vatC);
        totalCost.setText(euro + total);
    }


    private boolean checkPermission() {
        // checking for permissions.
        int permission1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int permission2 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        return permission1 == PackageManager.PERMISSION_GRANTED && permission2 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        // requesting permissions if not provided.
        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {

                // after requesting permissions we are showing
                // users a toast message of permission granted.
                boolean writeStorage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean readStorage = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                if (writeStorage && readStorage) {
                    Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission Denied.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    }
}