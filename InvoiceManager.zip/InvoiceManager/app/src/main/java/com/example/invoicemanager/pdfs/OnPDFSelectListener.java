package com.example.invoicemanager.pdfs;

import java.io.File;

public interface OnPDFSelectListener  {
    File onPdfSelected(File file);
}

