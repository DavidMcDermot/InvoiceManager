package com.example.invoicemanager.client;

import android.content.Intent;
import android.os.Bundle;

import com.example.invoicemanager.R;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ClientCreation extends AppCompatActivity {

    private EditText clientEdt, clientEmailEdt, clientAddEdt;
    private Button saveBtn;


    public static final String EXTRA_ID = "com.example.invoicemanager.EXTRA_ID";
    public static final String EXTRA_CLIENT_NAME = "com.example.invoicemanager.EXTRA_CLIENT_NAME";
    public static final String EXTRA_CLIENT_EMAIL = "com.example.invoicemanager.EXTRA_CLIENT_EMAIL";
    public static final String EXTRA_CLIENT_ADD = "com.example.invoicemanager.EXTRA_CLIENT_ADD";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_creation);

        clientEdt = findViewById(R.id.idEdtClientName);
        clientEmailEdt = findViewById(R.id.idEdtEmail);
        clientAddEdt = findViewById(R.id.idEdtClientAddress);
        saveBtn = findViewById(R.id.idBtnSaveC);

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            clientEdt.setText(intent.getStringExtra(EXTRA_CLIENT_NAME));
            clientEmailEdt.setText(intent.getStringExtra(EXTRA_CLIENT_EMAIL));
            clientAddEdt.setText(intent.getStringExtra(EXTRA_CLIENT_ADD));
        }


            saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            // getting text value from edittext and checking if the fields are empty or not.
                String clientName = clientEdt.getText().toString();
                String clientEmail = clientEmailEdt.getText().toString();
                String clientAdd = clientAddEdt.getText().toString();
                if (clientName.isEmpty() || clientEmail.isEmpty() || clientAdd.isEmpty()) {
                    Toast.makeText(ClientCreation.this, "Please enter valid client details.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // calling a method to save our course.
                saveClient(clientName, clientEmail, clientAdd);
            }
        });
    }

    private void saveClient(String clientName, String clientEmail, String clientAdd) {
        // passing all the data via an intent.
        Intent data = new Intent();

        // passing all our client information.
        data.putExtra(EXTRA_CLIENT_NAME, clientName);
        data.putExtra(EXTRA_CLIENT_EMAIL, clientEmail);
        data.putExtra(EXTRA_CLIENT_ADD, clientAdd);
        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            // passing id
            data.putExtra(EXTRA_ID, id);
        }

        //setting result as data.
        setResult(RESULT_OK, data);

        // display a toast message after adding information to confirm client addition
        Toast.makeText(this, "Client has been saved to Database. ", Toast.LENGTH_SHORT).show();
    }
}
