package com.example.invoicemanager.pdfs;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.invoicemanager.R;

import java.io.File;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainViewHolder> {
    public static final String ACTION_DELETE_DATA = "com.example.invoicemanager.pdfs.FILE_DELETED";

    private Context context;
    private List<File> pdfFiles;
    private PDFViewer viewer;


    public MainAdapter(Context context, List<File> pdfFiles, OnPDFSelectListener listener) {
        this.context = context;
        this.pdfFiles = pdfFiles;
        this.listener = listener;
    }

    private OnPDFSelectListener listener;

    public MainAdapter(Context context, List<File> pdfFiles) {
        this.context = context;
        this.pdfFiles = pdfFiles;

    }


    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MainViewHolder((LayoutInflater.from(context).inflate(R.layout.pdf_rv_item,parent,false)));
    }

    @Override
    public void onBindViewHolder(@NonNull MainViewHolder holder, int position) {

        holder.txtName.setText(pdfFiles.get(position).getName());
        holder.txtName.setSelected(true);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onPdfSelected(pdfFiles.get(position));
            }
        });

        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage("Are you sure you want to delete this file?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                File del = new File(pdfFiles.get(position).getAbsolutePath());

                                if (del.delete()) {
                                    Toast.makeText(view.getContext(), "File deleted successfully", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(MainAdapter.ACTION_DELETE_DATA);
                                    view.getContext().sendBroadcast(intent);
                                } else {
                                    Toast.makeText(view.getContext(), "Failed to delete file", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                builder.show();
                return false;
            }
        });

    }

    @Override
    public int getItemCount() {
        return pdfFiles.size();
    }

}


