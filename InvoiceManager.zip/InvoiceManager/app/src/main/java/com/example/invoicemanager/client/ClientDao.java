package com.example.invoicemanager.client;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ClientDao {

    @Insert
    void insert(Client client);

    @Insert
    void insertAll(Client...clients);

    @Delete
    void delete(Client client);

    @Query("DELETE FROM client")
    void deleteAllClients();

    @Update
    void update(Client client);

    @Query("Select * from Client where client_name Like :name")
    Client findByName(String name);

    @Query("Select * from Client where id Like :id")
    Client findById(int id);

    @Query("Select * from client")
    LiveData<List<Client>> getAllClients();
}
