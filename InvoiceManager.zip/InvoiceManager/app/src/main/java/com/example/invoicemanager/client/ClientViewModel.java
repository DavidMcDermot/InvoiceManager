package com.example.invoicemanager.client;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ClientViewModel extends AndroidViewModel {

    ClientRepository repository;
    LiveData<List<Client>> clientList;

    public ClientViewModel(Application application){
        super(application);
        repository = new ClientRepository(application);
        clientList = repository.getClient();
    }

    LiveData<List<Client>> getAllClients(){
        return clientList;
    }

    public void insertClient(Client client){
        repository.insert(client);
    }

    public void deleteClient(Client client){
        repository.delete(client);
    }

    public void deleteAllClient(Client client){
        repository.deleteAll();
    }

    public void updateClient(Client client){
        repository.update(client);
    }




}
