package com.example.invoicemanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Preferences extends AppCompatActivity {

    TextView name, address1, address2, address3, VATNum, email;
    Button saveBtn;

    SharedPreferences BusinessPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        BusinessPreferences = getSharedPreferences("bus_preferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = BusinessPreferences.edit();

        saveBtn = findViewById(R.id.saveBtn);
        name = findViewById(R.id.busNameEt);
        address1 = findViewById(R.id.add1Et);
        address2 = findViewById(R.id.add2Et);
        address3 = findViewById(R.id.add3Et);
        VATNum = findViewById(R.id.VATNumEt);
        email = findViewById(R.id.busEmailEt);

        // save the business details the user inputs to shared preferences
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String busName = name.getText().toString();
                String busAdd1 = address1.getText().toString();
                String busAdd2 = address2.getText().toString();
                String busAdd3 = address3.getText().toString();
                String busVat = VATNum.getText().toString();
                String busEmail = email.getText().toString();

                editor.putString("business_name", busName);
                editor.putString("business_add1", busAdd1 );
                editor.putString("business_add2", busAdd2 );
                editor.putString("business_add3", busAdd3 );
                editor.putString("business_vat_number", busVat);
                editor.putString("business_email", busEmail);
                editor.apply();

                System.out.println("Saved");

            }
        });


    }
}