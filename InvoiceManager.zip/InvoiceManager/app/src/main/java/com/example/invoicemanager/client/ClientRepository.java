package com.example.invoicemanager.client;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ClientRepository {

    ClientDao clientDao;
    private LiveData<List<Client>> allClients;

    public ClientRepository(Application application){

        AppDatabase db = AppDatabase.getInstance(application);
        clientDao = db.clientDao();
        allClients = clientDao.getAllClients();


    }

    void insert(Client client){

        new insertAsyncTask(clientDao).execute(client);
    }

    void delete(Client client){

        new deleteAsyncTask(clientDao).execute(client);
    }

    void update(Client client){

        new updateAsyncTask(clientDao).execute(client);
    }

    void deleteAll(){
        new deleteAllAsyncTask(clientDao).execute();
    }

    void findByName(String name){
        new findByNameAsyncTask(clientDao).execute(name);
    }

    LiveData<List<Client>> getClient(){
        return clientDao.getAllClients();

    }

    private static class updateAsyncTask extends AsyncTask<Client,Void,Void>{
        private ClientDao taskDao;

        updateAsyncTask(ClientDao clientDao){
            taskDao = clientDao;
        }
        @Override
        protected Void doInBackground(Client... clients){
            taskDao.update(clients[0]);
            return null;
        }

    }

    private static class insertAsyncTask extends AsyncTask<Client,Void,Void>{
            private ClientDao taskDao;

            insertAsyncTask(ClientDao clientDao){
                taskDao = clientDao;
            }
    @Override
        protected Void doInBackground(Client... clients){
             taskDao.insert(clients[0]);
             return null;
    }

    }

    private static class deleteAsyncTask extends AsyncTask<Client,Void,Void>{
        private ClientDao taskDao;

        deleteAsyncTask(ClientDao clientDao){
            taskDao = clientDao;
        }
        @Override
        protected Void doInBackground(Client... clients){
            taskDao.delete(clients[0]);
            return null;
        }

    }

    private static class deleteAllAsyncTask extends AsyncTask<Void,Void,Void>{
        private ClientDao taskDao;

        deleteAllAsyncTask(ClientDao clientDao){
            taskDao = clientDao;
        }
        @Override
        protected Void doInBackground(Void... voids){
            taskDao.deleteAllClients();
            return null;
        }

    }

    private static class findByNameAsyncTask extends AsyncTask<String,Void,Void>{
        private ClientDao taskDao;

        findByNameAsyncTask(ClientDao clientDao){
            taskDao = clientDao;
        }
        @Override
        protected Void doInBackground(String... name){
            taskDao.findByName(String.valueOf(name));
            return null;
        }

    }

}
