package com.example.invoicemanager.client;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Client")
public class Client {

    @PrimaryKey(autoGenerate = true)
    private int id;


    @ColumnInfo(name = "client_name")
    private String name;

    @ColumnInfo(name = "E-mail")
    private String email;

    @ColumnInfo(name = "Address")
    private String address;

    public Client(String name, String email, String address){
        this.name = name;
        this.email = email;
        this.address = address;
    }

    public Client(){

    }

    public String getName(){return name;}

    public void setName(String name){this.name = name;}

    public String getEmail(){return email;}

    public void setEmail(String email){this.email = email;}

    public String getAddress(){return address;}

    public void setAddress(String address){this.address = address;}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Client{" +
                "Name = '" + name + '\'' +
                ", E-mail = '" + email + '\'' +
                ", Address = '" + address + '\'' +
                '}';
    }

    }
