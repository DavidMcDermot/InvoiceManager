package com.example.invoicemanager.pdfs;

import static com.example.invoicemanager.pdfs.MainAdapter.ACTION_DELETE_DATA;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Environment;
import android.view.ContextMenu;
import android.view.View;

import com.example.invoicemanager.R;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PDFViewer extends AppCompatActivity implements  OnPDFSelectListener{

    private MainAdapter adapter;
    private List<File> pdfList;
    private RecyclerView recyclerView;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ACTION_DELETE_DATA)) {
                displayPDF();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, new IntentFilter(ACTION_DELETE_DATA));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdfviewer);
        displayPDF();

    }

    //find pdf files and add them to arraylist
    public ArrayList<File> findPdf(File dir) {
        ArrayList<File> arrayList = new ArrayList<>();
        File fileList[] = dir.listFiles();

        if (fileList != null) {

            for (int i = 0; i < fileList.length; i++) {

                if (fileList[i].isDirectory()) {
                    arrayList.addAll(findPdf(fileList[i]));
                } else {
                    if (fileList[i].getName().contains(".pdf")) {
                        arrayList.add(fileList[i]);
                    }
                }

            }
        }

        return arrayList;
    }

    public void displayPDF(){
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Invoices");

        recyclerView = findViewById(R.id.PDFrv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        pdfList = new ArrayList<>();
        pdfList.addAll(findPdf(dir));
        adapter = new MainAdapter(this, pdfList,this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public File onPdfSelected(File file) {

        startActivity(new Intent(PDFViewer.this,PdfActivity.class)
                .putExtra("path",file.getAbsolutePath()));
        return file;
    }

}